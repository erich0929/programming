namespace cpp hello
namespace java kr.co.jaso.hello.zkconf.generated
namespace php hello
namespace perl hello
namespace py hello

service HelloService {
    string greeting(1:string name, 2:i32 age)
} 