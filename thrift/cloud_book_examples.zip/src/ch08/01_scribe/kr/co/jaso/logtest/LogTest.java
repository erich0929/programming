package kr.co.jaso.logtest;

import kr.co.jaso.scribe.ScribeLogUtil;

public class LogTest {
  public static void main(String[] args) throws Exception {
    ScribeLogUtil.info("This is Test");
  }
}
